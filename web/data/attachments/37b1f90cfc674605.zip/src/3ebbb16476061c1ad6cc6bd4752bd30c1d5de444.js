// Generated from: features/login.feature
import { test } from "../../src/fixtures/index.ts";

test.describe('Autenticação e acesso à área do cliente', () => {

  test('Login com credenciais válidas', { tag: ['@login', '@positivo', '@smoke'] }, async ({ Given, When, Then, And, api, ctx, header, loginPage, page }) => { 
    await Given('que existe um cliente cadastrado', null, { api, ctx, page }); 
    await And('que estou na página de login', null, { loginPage, page }); 
    await When('eu faço login com as credenciais do cliente', null, { ctx, loginPage, page }); 
    await Then('devo ser redirecionado para a página "My account"', null, { loginPage, page }); 
    await And('devo ver o nome do cliente no menu de navegação', null, { ctx, header, page }); 
  });

  test('Navegar até o formulário de contato após o login', { tag: ['@login', '@positivo', '@smoke'] }, async ({ Given, When, Then, And, api, contactPage, ctx, header, loginPage, page }) => { 
    await Given('que existe um cliente cadastrado', null, { api, ctx, page }); 
    await And('que estou autenticado na aplicação', null, { ctx, loginPage, page }); 
    await When('eu acesso o menu "Contact"', null, { header, page }); 
    await Then('devo estar na página do formulário de contato', null, { contactPage, page }); 
    await And('o formulário deve estar identificado com os dados do cliente', null, { contactPage, ctx, page }); 
  });

  test('Enviar uma mensagem pelo formulário de contato', { tag: ['@login', '@positivo'] }, async ({ Given, When, Then, And, api, contactPage, ctx, header, loginPage, page }) => { 
    await Given('que existe um cliente cadastrado', null, { api, ctx, page }); 
    await And('que estou autenticado na aplicação', null, { ctx, loginPage, page }); 
    await And('que estou no formulário de contato', null, { contactPage, header, page }); 
    await When('eu envio a mensagem "Gostaria de saber o prazo de entrega para pedidos acima de 10 itens." com o assunto "Customer service"', null, { contactPage, page }); 
    await Then('devo ver a confirmação de envio "Thanks for your message! We will contact you shortly."', null, { contactPage, page }); 
  });

  test('Envio do formulário de contato sem os campos obrigatórios', { tag: ['@login', '@negativo'] }, async ({ Given, When, Then, And, api, contactPage, ctx, header, loginPage, page }) => { 
    await Given('que existe um cliente cadastrado', null, { api, ctx, page }); 
    await And('que estou autenticado na aplicação', null, { ctx, loginPage, page }); 
    await And('que estou no formulário de contato', null, { contactPage, header, page }); 
    await When('eu envio o formulário de contato sem preencher os campos', null, { contactPage, page }); 
    await Then('o campo "assunto" do contato deve exibir o erro "Subject is required"', null, { contactPage, page }); 
    await And('o campo "mensagem" do contato deve exibir o erro "Message is required"', null, { contactPage, page }); 
  });

  test('Login com senha incorreta', { tag: ['@login', '@negativo'] }, async ({ Given, When, Then, And, api, ctx, header, loginPage, page }) => { 
    await Given('que existe um cliente cadastrado', null, { api, ctx, page }); 
    await And('que estou na página de login', null, { loginPage, page }); 
    await When('eu faço login com o e-mail do cliente e a senha "SenhaErrada#123"', null, { ctx, loginPage, page }); 
    await Then('devo ver a mensagem de erro de login "Invalid email or password"', null, { loginPage, page }); 
    await And('devo permanecer na página de login sem estar autenticado', null, { header, loginPage, page }); 
  });

  test('Login com usuário inexistente', { tag: ['@login', '@negativo'] }, async ({ Given, When, Then, And, header, loginPage, page }) => { 
    await Given('que estou na página de login', null, { loginPage, page }); 
    await When('eu faço login com um e-mail não cadastrado', null, { loginPage, page }); 
    await Then('devo ver a mensagem de erro de login "Invalid email or password"', null, { loginPage, page }); 
    await And('devo permanecer na página de login sem estar autenticado', null, { header, loginPage, page }); 
  });

  test('Login com todos os campos obrigatórios em branco', { tag: ['@login', '@negativo'] }, async ({ Given, When, Then, And, header, loginPage, page }) => { 
    await Given('que estou na página de login', null, { loginPage, page }); 
    await When('eu faço login com o e-mail "" e a senha ""', null, { loginPage, page }); 
    await Then('o campo "e-mail" do login deve exibir o erro "Email is required"', null, { loginPage, page }); 
    await And('o campo "senha" do login deve exibir o erro "Password is required"', null, { loginPage, page }); 
    await And('devo permanecer na página de login sem estar autenticado', null, { header, loginPage, page }); 
  });

  test.describe('Validação dos campos do login - <situação>', () => {

    test('Validação dos campos do login - e-mail em branco', { tag: ['@login', '@negativo'] }, async ({ Given, When, Then, And, header, loginPage, page }) => { 
      await Given('que estou na página de login', null, { loginPage, page }); 
      await When('eu faço login com o e-mail "" e a senha "Senha#123"', null, { loginPage, page }); 
      await Then('o campo "e-mail" do login deve exibir o erro "Email is required"', null, { loginPage, page }); 
      await And('devo permanecer na página de login sem estar autenticado', null, { header, loginPage, page }); 
    });

    test('Validação dos campos do login - senha em branco', { tag: ['@login', '@negativo'] }, async ({ Given, When, Then, And, header, loginPage, page }) => { 
      await Given('que estou na página de login', null, { loginPage, page }); 
      await When('eu faço login com o e-mail "cliente@example.com" e a senha ""', null, { loginPage, page }); 
      await Then('o campo "senha" do login deve exibir o erro "Password is required"', null, { loginPage, page }); 
      await And('devo permanecer na página de login sem estar autenticado', null, { header, loginPage, page }); 
    });

    test('Validação dos campos do login - e-mail sem domínio', { tag: ['@login', '@negativo'] }, async ({ Given, When, Then, And, header, loginPage, page }) => { 
      await Given('que estou na página de login', null, { loginPage, page }); 
      await When('eu faço login com o e-mail "cliente@" e a senha "Senha#123"', null, { loginPage, page }); 
      await Then('o campo "e-mail" do login deve exibir o erro "Email format is invalid"', null, { loginPage, page }); 
      await And('devo permanecer na página de login sem estar autenticado', null, { header, loginPage, page }); 
    });

    test('Validação dos campos do login - senha curta demais', { tag: ['@login', '@negativo'] }, async ({ Given, When, Then, And, header, loginPage, page }) => { 
      await Given('que estou na página de login', null, { loginPage, page }); 
      await When('eu faço login com o e-mail "cliente@example.com" e a senha "ab"', null, { loginPage, page }); 
      await Then('o campo "senha" do login deve exibir o erro "Password length is invalid"', null, { loginPage, page }); 
      await And('devo permanecer na página de login sem estar autenticado', null, { header, loginPage, page }); 
    });

  });

  test('Conta bloqueada após três tentativas de senha incorreta', { tag: ['@login', '@negativo', '@seguranca'] }, async ({ Given, When, Then, And, api, ctx, header, loginPage, page }) => { 
    await Given('que existe um cliente cadastrado', null, { api, ctx, page }); 
    await And('que estou na página de login', null, { loginPage, page }); 
    await When('eu erro a senha do cliente 3 vezes seguidas', null, { ctx, loginPage, page }); 
    await And('eu faço login com as credenciais do cliente', null, { ctx, loginPage, page }); 
    await Then('devo ver a mensagem de erro de login "Account locked, too many failed attempts. Please contact the administrator."', null, { loginPage, page }); 
    await And('devo permanecer na página de login sem estar autenticado', null, { header, loginPage, page }); 
  });

});

// == technical section ==

test.beforeEach('BeforeEach Hooks', ({ $runScenarioHooks }) => $runScenarioHooks('before', {  }));

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/login.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":9,"tags":["@login","@positivo","@smoke"],"steps":[{"pwStepLine":7,"gherkinStepLine":10,"keywordType":"Context","textWithKeyword":"Dado que existe um cliente cadastrado","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":11,"keywordType":"Context","textWithKeyword":"E que estou na página de login","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":12,"keywordType":"Action","textWithKeyword":"Quando eu faço login com as credenciais do cliente","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":13,"keywordType":"Outcome","textWithKeyword":"Então devo ser redirecionado para a página \"My account\"","stepMatchArguments":[{"group":{"start":37,"value":"\"My account\"","children":[{"start":38,"value":"My account","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":11,"gherkinStepLine":14,"keywordType":"Outcome","textWithKeyword":"E devo ver o nome do cliente no menu de navegação","stepMatchArguments":[]}]},
  {"pwTestLine":14,"pickleLine":17,"tags":["@login","@positivo","@smoke"],"steps":[{"pwStepLine":15,"gherkinStepLine":18,"keywordType":"Context","textWithKeyword":"Dado que existe um cliente cadastrado","stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":19,"keywordType":"Context","textWithKeyword":"E que estou autenticado na aplicação","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":20,"keywordType":"Action","textWithKeyword":"Quando eu acesso o menu \"Contact\"","stepMatchArguments":[{"group":{"start":17,"value":"\"Contact\"","children":[{"start":18,"value":"Contact","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":21,"keywordType":"Outcome","textWithKeyword":"Então devo estar na página do formulário de contato","stepMatchArguments":[]},{"pwStepLine":19,"gherkinStepLine":22,"keywordType":"Outcome","textWithKeyword":"E o formulário deve estar identificado com os dados do cliente","stepMatchArguments":[]}]},
  {"pwTestLine":22,"pickleLine":25,"tags":["@login","@positivo"],"steps":[{"pwStepLine":23,"gherkinStepLine":26,"keywordType":"Context","textWithKeyword":"Dado que existe um cliente cadastrado","stepMatchArguments":[]},{"pwStepLine":24,"gherkinStepLine":27,"keywordType":"Context","textWithKeyword":"E que estou autenticado na aplicação","stepMatchArguments":[]},{"pwStepLine":25,"gherkinStepLine":28,"keywordType":"Context","textWithKeyword":"E que estou no formulário de contato","stepMatchArguments":[]},{"pwStepLine":26,"gherkinStepLine":29,"keywordType":"Action","textWithKeyword":"Quando eu envio a mensagem \"Gostaria de saber o prazo de entrega para pedidos acima de 10 itens.\" com o assunto \"Customer service\"","stepMatchArguments":[{"group":{"start":20,"value":"\"Gostaria de saber o prazo de entrega para pedidos acima de 10 itens.\"","children":[{"start":21,"value":"Gostaria de saber o prazo de entrega para pedidos acima de 10 itens.","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":105,"value":"\"Customer service\"","children":[{"start":106,"value":"Customer service","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":27,"gherkinStepLine":30,"keywordType":"Outcome","textWithKeyword":"Então devo ver a confirmação de envio \"Thanks for your message! We will contact you shortly.\"","stepMatchArguments":[{"group":{"start":32,"value":"\"Thanks for your message! We will contact you shortly.\"","children":[{"start":33,"value":"Thanks for your message! We will contact you shortly.","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":30,"pickleLine":33,"tags":["@login","@negativo"],"steps":[{"pwStepLine":31,"gherkinStepLine":34,"keywordType":"Context","textWithKeyword":"Dado que existe um cliente cadastrado","stepMatchArguments":[]},{"pwStepLine":32,"gherkinStepLine":35,"keywordType":"Context","textWithKeyword":"E que estou autenticado na aplicação","stepMatchArguments":[]},{"pwStepLine":33,"gherkinStepLine":36,"keywordType":"Context","textWithKeyword":"E que estou no formulário de contato","stepMatchArguments":[]},{"pwStepLine":34,"gherkinStepLine":37,"keywordType":"Action","textWithKeyword":"Quando eu envio o formulário de contato sem preencher os campos","stepMatchArguments":[]},{"pwStepLine":35,"gherkinStepLine":38,"keywordType":"Outcome","textWithKeyword":"Então o campo \"assunto\" do contato deve exibir o erro \"Subject is required\"","stepMatchArguments":[{"group":{"start":8,"value":"\"assunto\"","children":[{"start":9,"value":"assunto","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":48,"value":"\"Subject is required\"","children":[{"start":49,"value":"Subject is required","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":36,"gherkinStepLine":39,"keywordType":"Outcome","textWithKeyword":"E o campo \"mensagem\" do contato deve exibir o erro \"Message is required\"","stepMatchArguments":[{"group":{"start":8,"value":"\"mensagem\"","children":[{"start":9,"value":"mensagem","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":49,"value":"\"Message is required\"","children":[{"start":50,"value":"Message is required","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":39,"pickleLine":42,"tags":["@login","@negativo"],"steps":[{"pwStepLine":40,"gherkinStepLine":43,"keywordType":"Context","textWithKeyword":"Dado que existe um cliente cadastrado","stepMatchArguments":[]},{"pwStepLine":41,"gherkinStepLine":44,"keywordType":"Context","textWithKeyword":"E que estou na página de login","stepMatchArguments":[]},{"pwStepLine":42,"gherkinStepLine":45,"keywordType":"Action","textWithKeyword":"Quando eu faço login com o e-mail do cliente e a senha \"SenhaErrada#123\"","stepMatchArguments":[{"group":{"start":48,"value":"\"SenhaErrada#123\"","children":[{"start":49,"value":"SenhaErrada#123","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":43,"gherkinStepLine":46,"keywordType":"Outcome","textWithKeyword":"Então devo ver a mensagem de erro de login \"Invalid email or password\"","stepMatchArguments":[{"group":{"start":37,"value":"\"Invalid email or password\"","children":[{"start":38,"value":"Invalid email or password","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":44,"gherkinStepLine":47,"keywordType":"Outcome","textWithKeyword":"E devo permanecer na página de login sem estar autenticado","stepMatchArguments":[]}]},
  {"pwTestLine":47,"pickleLine":50,"tags":["@login","@negativo"],"steps":[{"pwStepLine":48,"gherkinStepLine":51,"keywordType":"Context","textWithKeyword":"Dado que estou na página de login","stepMatchArguments":[]},{"pwStepLine":49,"gherkinStepLine":52,"keywordType":"Action","textWithKeyword":"Quando eu faço login com um e-mail não cadastrado","stepMatchArguments":[]},{"pwStepLine":50,"gherkinStepLine":53,"keywordType":"Outcome","textWithKeyword":"Então devo ver a mensagem de erro de login \"Invalid email or password\"","stepMatchArguments":[{"group":{"start":37,"value":"\"Invalid email or password\"","children":[{"start":38,"value":"Invalid email or password","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":51,"gherkinStepLine":54,"keywordType":"Outcome","textWithKeyword":"E devo permanecer na página de login sem estar autenticado","stepMatchArguments":[]}]},
  {"pwTestLine":54,"pickleLine":57,"tags":["@login","@negativo"],"steps":[{"pwStepLine":55,"gherkinStepLine":58,"keywordType":"Context","textWithKeyword":"Dado que estou na página de login","stepMatchArguments":[]},{"pwStepLine":56,"gherkinStepLine":59,"keywordType":"Action","textWithKeyword":"Quando eu faço login com o e-mail \"\" e a senha \"\"","stepMatchArguments":[{"group":{"start":27,"value":"\"\"","children":[{"start":28,"value":"","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":40,"value":"\"\"","children":[{"start":41,"value":"","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":57,"gherkinStepLine":60,"keywordType":"Outcome","textWithKeyword":"Então o campo \"e-mail\" do login deve exibir o erro \"Email is required\"","stepMatchArguments":[{"group":{"start":8,"value":"\"e-mail\"","children":[{"start":9,"value":"e-mail","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":45,"value":"\"Email is required\"","children":[{"start":46,"value":"Email is required","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":58,"gherkinStepLine":61,"keywordType":"Outcome","textWithKeyword":"E o campo \"senha\" do login deve exibir o erro \"Password is required\"","stepMatchArguments":[{"group":{"start":8,"value":"\"senha\"","children":[{"start":9,"value":"senha","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":44,"value":"\"Password is required\"","children":[{"start":45,"value":"Password is required","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":59,"gherkinStepLine":62,"keywordType":"Outcome","textWithKeyword":"E devo permanecer na página de login sem estar autenticado","stepMatchArguments":[]}]},
  {"pwTestLine":64,"pickleLine":73,"tags":["@login","@negativo"],"steps":[{"pwStepLine":65,"gherkinStepLine":66,"keywordType":"Context","textWithKeyword":"Dado que estou na página de login","stepMatchArguments":[]},{"pwStepLine":66,"gherkinStepLine":67,"keywordType":"Action","textWithKeyword":"Quando eu faço login com o e-mail \"\" e a senha \"Senha#123\"","stepMatchArguments":[{"group":{"start":27,"value":"\"\"","children":[{"start":28,"value":"","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":40,"value":"\"Senha#123\"","children":[{"start":41,"value":"Senha#123","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":67,"gherkinStepLine":68,"keywordType":"Outcome","textWithKeyword":"Então o campo \"e-mail\" do login deve exibir o erro \"Email is required\"","stepMatchArguments":[{"group":{"start":8,"value":"\"e-mail\"","children":[{"start":9,"value":"e-mail","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":45,"value":"\"Email is required\"","children":[{"start":46,"value":"Email is required","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":68,"gherkinStepLine":69,"keywordType":"Outcome","textWithKeyword":"E devo permanecer na página de login sem estar autenticado","stepMatchArguments":[]}]},
  {"pwTestLine":71,"pickleLine":74,"tags":["@login","@negativo"],"steps":[{"pwStepLine":72,"gherkinStepLine":66,"keywordType":"Context","textWithKeyword":"Dado que estou na página de login","stepMatchArguments":[]},{"pwStepLine":73,"gherkinStepLine":67,"keywordType":"Action","textWithKeyword":"Quando eu faço login com o e-mail \"cliente@example.com\" e a senha \"\"","stepMatchArguments":[{"group":{"start":27,"value":"\"cliente@example.com\"","children":[{"start":28,"value":"cliente@example.com","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":59,"value":"\"\"","children":[{"start":60,"value":"","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":74,"gherkinStepLine":68,"keywordType":"Outcome","textWithKeyword":"Então o campo \"senha\" do login deve exibir o erro \"Password is required\"","stepMatchArguments":[{"group":{"start":8,"value":"\"senha\"","children":[{"start":9,"value":"senha","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":44,"value":"\"Password is required\"","children":[{"start":45,"value":"Password is required","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":75,"gherkinStepLine":69,"keywordType":"Outcome","textWithKeyword":"E devo permanecer na página de login sem estar autenticado","stepMatchArguments":[]}]},
  {"pwTestLine":78,"pickleLine":75,"tags":["@login","@negativo"],"steps":[{"pwStepLine":79,"gherkinStepLine":66,"keywordType":"Context","textWithKeyword":"Dado que estou na página de login","stepMatchArguments":[]},{"pwStepLine":80,"gherkinStepLine":67,"keywordType":"Action","textWithKeyword":"Quando eu faço login com o e-mail \"cliente@\" e a senha \"Senha#123\"","stepMatchArguments":[{"group":{"start":27,"value":"\"cliente@\"","children":[{"start":28,"value":"cliente@","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":48,"value":"\"Senha#123\"","children":[{"start":49,"value":"Senha#123","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":81,"gherkinStepLine":68,"keywordType":"Outcome","textWithKeyword":"Então o campo \"e-mail\" do login deve exibir o erro \"Email format is invalid\"","stepMatchArguments":[{"group":{"start":8,"value":"\"e-mail\"","children":[{"start":9,"value":"e-mail","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":45,"value":"\"Email format is invalid\"","children":[{"start":46,"value":"Email format is invalid","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":82,"gherkinStepLine":69,"keywordType":"Outcome","textWithKeyword":"E devo permanecer na página de login sem estar autenticado","stepMatchArguments":[]}]},
  {"pwTestLine":85,"pickleLine":76,"tags":["@login","@negativo"],"steps":[{"pwStepLine":86,"gherkinStepLine":66,"keywordType":"Context","textWithKeyword":"Dado que estou na página de login","stepMatchArguments":[]},{"pwStepLine":87,"gherkinStepLine":67,"keywordType":"Action","textWithKeyword":"Quando eu faço login com o e-mail \"cliente@example.com\" e a senha \"ab\"","stepMatchArguments":[{"group":{"start":27,"value":"\"cliente@example.com\"","children":[{"start":28,"value":"cliente@example.com","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":59,"value":"\"ab\"","children":[{"start":60,"value":"ab","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":88,"gherkinStepLine":68,"keywordType":"Outcome","textWithKeyword":"Então o campo \"senha\" do login deve exibir o erro \"Password length is invalid\"","stepMatchArguments":[{"group":{"start":8,"value":"\"senha\"","children":[{"start":9,"value":"senha","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":44,"value":"\"Password length is invalid\"","children":[{"start":45,"value":"Password length is invalid","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":89,"gherkinStepLine":69,"keywordType":"Outcome","textWithKeyword":"E devo permanecer na página de login sem estar autenticado","stepMatchArguments":[]}]},
  {"pwTestLine":94,"pickleLine":79,"tags":["@login","@negativo","@seguranca"],"steps":[{"pwStepLine":95,"gherkinStepLine":80,"keywordType":"Context","textWithKeyword":"Dado que existe um cliente cadastrado","stepMatchArguments":[]},{"pwStepLine":96,"gherkinStepLine":81,"keywordType":"Context","textWithKeyword":"E que estou na página de login","stepMatchArguments":[]},{"pwStepLine":97,"gherkinStepLine":82,"keywordType":"Action","textWithKeyword":"Quando eu erro a senha do cliente 3 vezes seguidas","stepMatchArguments":[{"group":{"start":27,"value":"3"},"parameterTypeName":"int"}]},{"pwStepLine":98,"gherkinStepLine":83,"keywordType":"Action","textWithKeyword":"E eu faço login com as credenciais do cliente","stepMatchArguments":[]},{"pwStepLine":99,"gherkinStepLine":84,"keywordType":"Outcome","textWithKeyword":"Então devo ver a mensagem de erro de login \"Account locked, too many failed attempts. Please contact the administrator.\"","stepMatchArguments":[{"group":{"start":37,"value":"\"Account locked, too many failed attempts. Please contact the administrator.\"","children":[{"start":38,"value":"Account locked, too many failed attempts. Please contact the administrator.","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":100,"gherkinStepLine":85,"keywordType":"Outcome","textWithKeyword":"E devo permanecer na página de login sem estar autenticado","stepMatchArguments":[]}]},
]; // bdd-data-end